public class Animal{
	private int weight;
	public void print(){
		System.out.println("Animal: "+weight);
	}
}
