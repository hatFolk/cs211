public abstract class MyClass{
	private static int count = 0;
	public static String store;
	private boolean available;
	public Integer num;

	public MyClass(){
		count++;
	}

	private void func1(){
		// Do nothing
	}

	public void func2(){
		// Do nothing
	}

	private static void func3(){
		// Do nothing
	}

	public static void func4(){
		// Do nothing
	}
}
