public class Person{
	private String name = "default";
	public Person(String n){
		name = n;
	}
	public void print(){
		System.out.print("person :"+ name);
	}
}
