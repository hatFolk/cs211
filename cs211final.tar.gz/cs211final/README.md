All Text, PDFs, and Code Samples were written by Dr. Kinga Dobolyi or her TAs.
These files are made to make studying easier.
Included is a tarball which has everything in here already.
